from django.db.models.signals import post_save
from django.dispatch import receiver

from django.conf import settings
from django.core.mail import send_mail
from .models import User

from .models import *


@receiver(post_save, sender=User)
def create_profile(sender, instance, created, **kwargs):
    if created:
        if instance.is_user == True:
            UserProfile.objects.create(user=instance)
            print('Profile created successfully')


        elif instance.is_author == True:
            AuthorsProfile.objects.create(author=instance)

        elif instance.is_admin == True:
            AdminProfile.objects.create(user=instance)


@receiver(post_save, sender=User)
def update_profile(sender, instance, created, **kwargs):
    
    try:
        if created == False:
            if instance.is_user == True:
                instance.Userprofile.save()
                print('Profile updated successfully')

            if instance.is_author == True:
                instance.AuthorsProfile.save()
                print('Profile updated successfully')

            if instance.is_admin == True:
                instance.AdminProfile.save()
                print('Profile updated successfully')

    except:
        instance.userprofile = None



# @receiver(post_save, sender=User)
# def send_confirmation_email(sender, instance, created, **kwargs):
#     if created and not sender.is_active: # only send to unverified emails
#         subject = 'Please confirm your email address'
#         message = 'Thank you for registering. Please click the link below to confirm your email address:\n\n{}/verify/{}/'.format(settings.SITE_URL, instance.pk)
#         send_mail(
#             subject,
#             message,
#             settings.EMAIL_HOST_USER,
#             [instance.email],
#             fail_silently=False,
#         )
# @receiver(post_save, sender=Authors)
# def create_profile(sender, instance, created, **kwargs):
#     if created:
#         AuthorsProfile.objects.create(author=instance)
#         print('Profile created successfully')

# @receiver(post_save, sender=Authors)
# def update_profile(sender, instance, created, **kwargs):
    
#     try:
#         if created == False:
#             instance.AuthorProfile.save()
#             print('Profile updated successfully')

#     except:
#         instance.authorprofile = None
